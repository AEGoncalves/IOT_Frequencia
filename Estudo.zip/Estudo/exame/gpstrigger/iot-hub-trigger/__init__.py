import logging
import azure.functions as func
import json
import os
from azure.iot.hub import IoTHubRegistryManager
from azure.iot.hub.models import CloudToDeviceMethod

def main(event: func.EventHubEvent):
    try:
        raw = event.get_body().decode("utf-8")
        logging.info(f"RAW={raw}")

        body = json.loads(raw)
        # no teu caso, isto vira uma string tipo: {"longitude": -7.48}
        if isinstance(body, str):
            body = json.loads(body)

        logging.info(f"BODY={body}")

        device_id = event.iothub_metadata.get("connection-device-id") \
            or event.iothub_metadata.get("iothub-connection-device-id")

        logging.info(f"DEVICE_ID={device_id}")

        lon = body["longitude"]
        method_name = "led_verde.on" if lon > 0 else "led_vermelho.on"

        registry_manager = IoTHubRegistryManager(os.environ["REGISTRY_MANAGER_CONNECTION_STRING"])
        registry_manager.invoke_device_method(
            device_id,
            CloudToDeviceMethod(method_name=method_name, payload={})
        )

        logging.info(f"SENT_METHOD={method_name}")

    except Exception:
        logging.exception("FUNCTION ERROR")


